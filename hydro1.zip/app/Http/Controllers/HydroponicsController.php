<?php

namespace App\Http\Controllers;

use App\Services\FirebaseService;

class HydroponicsController extends Controller
{
    protected $firebaseService;

    public function __construct(FirebaseService $firebaseService)
    {
        $this->firebaseService = $firebaseService;
    }

    // Fetch data from Firebase
    public function getSensorReadings()
    {
        $data = $this->firebaseService->getSensorData();

        if ($data) {
            // Process the data
            return response()->json([
                'status' => 'success',
                'data' => $data
            ]);
        }

        return response()->json([
            'status' => 'error',
            'message' => 'Failed to fetch data from Firebase.'
        ]);
    }



    // Removed showSensorData method as sensor data is now shown in dht11 page
    /*
    public function showSensorData()
    {
        $data = $this->firebaseService->getSensorData();

        return view('hydroponics.sensor-data', ['sensorData' => $data]);
    }
    */

    public function ph4502c()
    {
        return view('hydroponics.ph4502c', ['sensorData' => []]);
    }
    public function about()
    {
        return view('hydroponics.about');
    }


    public function dht11()
    {
        $data = $this->firebaseService->getSensorData();
        return view('hydroponics.dht11', ['sensorData' => $data]);
    }

    public function hc_sr04()
    {
        return view('hydroponics.hc_sr04', ['sensorData' => []]);
    }

    public function dataAnalytics()
    {
        $data = $this->firebaseService->getSensorData();
        return view('hydroponics.data_analytics', ['sensorData' => $data]);
    }

}
