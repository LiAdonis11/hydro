<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\DHT11Reading;
use App\Models\HCSR04Reading;
use App\Models\PH4502CReading;

class SensorController extends Controller
{
    public function showDHT11() {
        $reading = DHT11Reading::latest()->first();
        return view('hydroponics.dht11', compact('reading'));
    }

    public function showHCSR04() {
        $reading = HCSR04Reading::latest()->first();
        return view('hydroponics.hc_sr04', compact('reading'));
    }

    public function showPH4502C() {
        $reading = PH4502CReading::latest()->first();
        return view('hydroponics.ph4502c', compact('reading'));
    }
}
