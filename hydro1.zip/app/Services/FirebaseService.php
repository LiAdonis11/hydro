<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class FirebaseService
{
    protected $firebaseUrl;
    protected $firebaseAuth;

    public function __construct()
    {
        // Firebase URL and Authentication Token
        $this->firebaseUrl = 'https://hydro-ba777-default-rtdb.asia-southeast1.firebasedatabase.app/';
        $this->firebaseAuth = 'AIzaSyDyj9vvIR6i4DMB2Xy8QEk2KDPxt2rZrQk'; // Use your Firebase database secret key
    }

    // Get data from Firebase
    public function getSensorData()
    {
        $response = Http::get($this->firebaseUrl . '/hydroponics.json?auth=' . $this->firebaseAuth);

        if ($response->successful()) {
            return $response->json(); // returns the data as an array
        }

        return null;
    }
}
