CREATE TABLE IF NOT EXISTS "posts" ("id" integer primary key autoincrement not null, "created_at" datetime, "updated_at" datetime);
