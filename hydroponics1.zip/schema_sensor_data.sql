CREATE TABLE IF NOT EXISTS "sensor_data" ("id" integer primary key autoincrement not null, "temperature" float not null, "humidity" float not null, "created_at" datetime, "updated_at" datetime);
